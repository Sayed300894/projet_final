<?php
require('actions/database.php');

$getAllQ = $bdd->query('SELECT id, id_author, title, `description`, pseudo_author, date_publication FROM questions ORDER BY id desc LIMIT 5');

if(isset($_GET['search']) && !empty(['search'])){

    $userChearch = $_GET['search'];

    $getAllQ = $bdd->query('SELECT id, id_author, title, `description`, pseudo_author, date_publication FROM questions WHERE title LIKE "%'.$userChearch.'%" order by id desc');

}